<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

// Response preflight request (OPTIONS) dari Ngrok / Expo
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/env.php';

$host = env_get('DB_HOST', 'localhost');
$user = env_get('DB_USER', 'root');
$pass = env_get('DB_PASS', '');
$dbname = env_get('DB_NAME', 'ambativasi');

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    echo json_encode([
        "status" => "error",
        "message" => "Koneksi database gagal: " . $conn->connect_error
    ]);
    exit();
}

// Pastikan tabel pendukung ada (aman dipanggil berulang: IF NOT EXISTS)
$conn->query("CREATE TABLE IF NOT EXISTS user_xp (
    id INT(11) NOT NULL AUTO_INCREMENT,
    user_id INT(11) NOT NULL,
    total_xp INT(11) NOT NULL DEFAULT 0,
    attempts INT(11) NOT NULL DEFAULT 0,
    last_streak_bonus_date DATE DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
?>